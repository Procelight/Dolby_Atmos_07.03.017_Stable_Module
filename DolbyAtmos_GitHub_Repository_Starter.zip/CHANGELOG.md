# Changelog

## 07.03.017 — experimental packaging update

- Replaced the base module's `MotoDolbyDax3.apk` with the provided Motorola Dolby UI APK `07.03.017`.
- Updated module metadata:
  - Name: `Dolby Atmos Stable`
  - ID: `DolbyAtmos` (preserved)
  - Version: `07.03.017`
  - Version code: `70301700`
  - Author field: `Procelight`
- Preserved the remaining files from the supplied Dolby Atmos v3.0 base package.

### Important

This is a UI APK update and metadata change, not a complete update of every Dolby engine/HAL/vendor component. The ZIP archive integrity was checked, but this build remains experimental and has not been independently tested across devices.
