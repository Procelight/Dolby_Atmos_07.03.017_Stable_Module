# Requirements and compatibility

## Minimum stated app requirement
- Android 12+ for the supplied UI APK.

## Intended setup
- Moto G54 5G
- Infinity X 3.12
- Android 16
- KernelSU Next
- Magic Mount-compatible systemless mounting

These are the target details reported for this build, not a claim of independently verified compatibility.

## Required precautions
- Backup of important data.
- A copy of the last known-working module ZIP.
- A reliable way to disable/remove the module if the phone does not boot normally.
- No other active Dolby port or conflicting audio modification module.

## Not guaranteed
- Compatibility with every Android 12+ device.
- Compatibility with every KernelSU Next version or mount implementation.
- Successful Dolby HAL/service startup.
- Audio effect operation merely because the UI opens.
- Boot safety on any device.
