---
name: Bug report
about: Report a reproducible installation, boot, UI, or audio issue
title: "[Bug] "
labels: bug
assignees: ""
---

## Device and software
- Device:
- ROM and version:
- Android version:
- Root manager/version:
- Mount method/module:
- Module release:

## Problem type
- [ ] Installation failure
- [ ] Boot issue
- [ ] Dolby UI crash
- [ ] UI opens but audio effect does not work
- [ ] Other

## Steps to reproduce
1.
2.
3.

## Expected behaviour


## Actual behaviour


## Logs
Attach relevant install/crash logs after removing private information. Do not include IMEI, serial number, account details, or private notifications.

## Safety check
- [ ] I have a backup/recovery path.
- [ ] I checked for conflicting Dolby/audio modules.
