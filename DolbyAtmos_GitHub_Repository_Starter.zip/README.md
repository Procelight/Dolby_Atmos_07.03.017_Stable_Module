# Dolby Atmos Stable — 07.03.017

A community-built, **experimental** KernelSU Next module package that uses the Motorola Dolby UI APK version **07.03.017** with files from the supplied Dolby Atmos v3.0 base module.

> **Status: Experimental / device testing required.** The archive structure was checked, but this package has not been independently validated on every ROM/device. It is not an official Motorola, Dolby, KernelSU, or Infinity X release.

## Package details

| Item | Value |
|---|---|
| Module display name | Dolby Atmos Stable |
| Module ID | `DolbyAtmos` |
| Module version | `07.03.017` |
| Module version code | `70301700` (matches the UI APK's system version code; not a separate module build number) |
| Module author field | Procelight |
| Target root manager | KernelSU Next (compatibility intended; not guaranteed) |
| Tested target reported by maintainer | Moto G54 5G, Infinity X 3.12, Android 16 |
| Mount approach | Intended for Magic Mount-compatible systemless mounting |
| UI package | `com.motorola.dolby.dolbyui` |
| Minimum Android level stated by APK source | Android 12+ |

## What this project changes

- Updates the Dolby UI APK to `07.03.017`.
- Retains the supporting files and install scripts from the supplied Dolby Atmos v3.0 base.
- Updates the module metadata to display version `07.03.017` and author `Procelight`.

It does **not** mean that the Dolby audio engine, HAL, vendor libraries, or audio effects have been upgraded to the same version. The module still contains components from its base package.

## Requirements

- Android 12 or newer (the UI APK's stated minimum; this alone does not guarantee ROM compatibility).
- Root access through KernelSU Next or another compatible root manager.
- A compatible Motorola/Dolby audio stack and ROM.
- Sufficient free storage.
- A current backup and a known way to disable/remove a module if Android fails to boot.
- No conflicting Dolby/audio enhancement modules enabled at the same time.

**Compatibility note:** The primary target reported for this build is Moto G54 5G + Infinity X 3.12 + Android 16 + KernelSU Next. Other devices and ROMs are unverified. Magic Mount compatibility is intended, not a universal guarantee.

## Installation

1. Read this README and the release notes completely.
2. Save a copy of your currently working module ZIP and any other important data.
3. Disable/remove other Dolby modules that may conflict. Do not run multiple Dolby ports simultaneously.
4. In KernelSU Next, install the release ZIP using the module installation flow.
5. Reboot only when you have a recovery plan available.
6. Verify both the app UI and actual audio effect operation. An app opening successfully does not prove the audio HAL/effects are working.

If booting, audio, or app launch fails, disable/remove the new module from KernelSU Next or use your established recovery method, then restore your known-working ZIP. Do not keep flashing additional audio modules to try to fix a failure.

## Known limitations

- Experimental build; no broad device/ROM test matrix is available.
- The UI APK version is newer than the base module's original UI. New UI features may depend on services, framework components, permissions, or vendor interfaces not present in every ROM.
- Audio effects can fail even if the UI opens.
- The APK's Android 12+ requirement is not proof of compatibility with Android 16 or a particular device.
- No guarantee is made that the module is safe for every device or that it will be bootloop-free.

## Reporting a bug

When opening an issue, include:

- Device model
- ROM name and exact version
- Android version and build fingerprint (redact anything you consider private)
- Root manager and version
- Mount module/approach
- Whether the issue is: install failure, boot issue, UI crash, or no audio effect
- Relevant KernelSU install log and Android crash log, with personal information removed
- Steps to reproduce

Do **not** post IMEI, serial number, account information, private notifications, or other sensitive data. Never report “works” based only on the UI opening; test actual audio playback.

## Credits and third-party components

- Motorola / Dolby: original app, trademarks, and proprietary components.
- Original Dolby Atmos v3.0 module author credited in the supplied base: Night_wolf19.
- The base package references work/credits associated with Cancunf and Ryuki.
- Procelight: module metadata/packaging for this experimental UI update.

All third-party rights remain with their respective owners. This project is not affiliated with or endorsed by Motorola, Dolby, KernelSU Next, or the Infinity X team.

## Redistribution and GitHub upload

Before publishing the binary ZIP, confirm that you have permission to redistribute **all** included third-party APKs, libraries, frameworks, and other files. A public repository upload can redistribute those files to anyone. If you do not have permission, publish the README and your own scripts/metadata only, and link users to the original sources instead of committing proprietary binaries.

Do not label this an official Motorola/Dolby release. Do not add an open-source license to third-party binaries you do not own.

## Releases

Use GitHub **Releases** to attach the installable ZIP. Keep the repository source/docs separate from binary assets where licensing requires it. Add a SHA-256 checksum to each release so users can verify the downloaded file.

## Disclaimer

Use at your own risk. Root modules can cause boot failures, audio problems, or system instability. Maintainers provide no warranty. Make a backup and keep a recovery path before installation.
