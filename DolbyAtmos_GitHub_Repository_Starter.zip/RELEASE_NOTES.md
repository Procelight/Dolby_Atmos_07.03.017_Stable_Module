# Dolby Atmos Stable 07.03.017 — Experimental

This release packages the Motorola Dolby UI APK `07.03.017` into the supplied Dolby Atmos v3.0 module base and updates module metadata.

**Target reported:** Moto G54 5G / Infinity X 3.12 / Android 16 / KernelSU Next.

**Before installing:** back up your working module, disable conflicting Dolby ports, and make sure you know how to recover if the phone fails to boot.

**Testing status:** archive integrity checked; device compatibility and audio-engine operation are not independently verified.

**Redistribution:** only attach the binary ZIP if you have permission to redistribute every included third-party APK/library/component.
